EL SOL — strona projektu z hiszpańskiego

Pliki:
- index.html — gotowa, responsywna strona internetowa.

Jak uruchomić:
1. Otwórz index.html w przeglądarce albo prześlij plik do hostingu.
2. Zdjęcia i fonty ładują się z internetu, więc do ich wyświetlenia potrzebne jest połączenie.
3. Dane kontaktowe są przykładowe. Numer telefonu jest fikcyjny.

Publikacja przez GitHub Pages:
1. Utwórz repozytorium GitHub i dodaj do niego index.html.
2. Otwórz Settings → Pages.
3. W sekcji Build and deployment wybierz Deploy from a branch.
4. Wybierz gałąź main oraz folder /(root), a następnie Save.
5. Po chwili GitHub pokaże adres opublikowanej strony.
